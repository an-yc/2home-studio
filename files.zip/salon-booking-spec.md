# Hair Salon Appointment Booking System
## Product Specification Document

---

## Executive Summary

A lightweight, embeddable booking system designed for a solo hair stylist to manage appointments directly from their website. The system prioritizes simplicity, data ownership, and preventing double bookings while providing a seamless client experience.

---

## Core Requirements

### Business Context
- **Single Stylist Operation**: Only one service provider, simplifying scheduling logic
- **Data Ownership**: All client data remains under the salon owner's control
- **No Double Booking**: Critical constraint - each time slot can only be booked once
- **Website Integration**: Must be embeddable as a widget/component on existing website

### User Data Collection (Minimal)
| Field | Type | Required | Purpose |
|-------|------|----------|---------|
| Service Type | Selection | Yes | Determine appointment duration |
| Client Name | Text | Yes | Identification |
| Phone Number | Tel | Yes | Primary contact for reminders |
| Email Address | Email | Yes | Confirmation & reminders |

---

## Functional Specifications

### 1. Service Selection
**Features:**
- Pre-configured list of services with durations
- Clear pricing display (optional)
- Service descriptions
- Duration indicator for scheduling

**Example Services:**
| Service | Duration | 
|---------|----------|
| Haircut | 45 min |
| Color | 90 min |
| Highlights | 120 min |
| Blowout | 30 min |
| Treatment | 60 min |

### 2. Date & Time Selection
**Features:**
- Calendar view showing available dates
- Time slots based on stylist's working hours
- Real-time availability (slots disappear when booked)
- Service duration awareness (blocks appropriate time)
- Buffer time between appointments (configurable)

**Availability Logic:**
```
Available Slot = Working Hours - (Booked Appointments + Buffer Time)
```

**Anti-Double Booking Mechanism:**
- Database-level unique constraint on (date, time_slot)
- Optimistic locking with version check
- Real-time slot refresh before confirmation
- Transaction-based booking with rollback on conflict

### 3. Client Information Form
**Form Fields:**
- Full Name (text, required, min 2 chars)
- Phone Number (tel, required, validated format)
- Email Address (email, required, validated format)
- Special Notes (textarea, optional, max 500 chars)

**Validation:**
- Client-side validation for immediate feedback
- Server-side validation before database write
- Sanitization of all inputs

### 4. Confirmation Flow
**Steps:**
1. Display booking summary
2. Require explicit confirmation click
3. Create booking record
4. Send confirmation email from your domain
5. Show success message with details

**Confirmation Email Contains:**
- Appointment date & time
- Service booked
- Salon address
- Cancellation/reschedule instructions
- Contact information

---

## Technical Architecture

### Frontend (Embeddable Widget)
```
Technology: React (JSX) - single file component
Styling: Tailwind CSS (embedded)
State: React useState/useReducer
```

**Component Structure:**
```
<SalonBooking>
  ├── <ServiceSelector />
  ├── <DateTimePicker />
  │   ├── <Calendar />
  │   └── <TimeSlots />
  ├── <ClientForm />
  └── <ConfirmationModal />
</SalonBooking>
```

### Backend Integration Points

**Option A: Simple Backend (Recommended for Solo)**
- JSON file storage or SQLite
- Node.js/Express or Python/Flask
- Cron job for email reminders

**Option B: Serverless**
- Firebase/Supabase for database
- Cloud Functions for booking logic
- SendGrid/Mailgun for emails

**Option C: WordPress Integration**
- Custom plugin or existing salon plugin
- WP REST API endpoints

### API Endpoints Required
```
GET  /api/services           - List available services
GET  /api/availability       - Get available time slots for date range
POST /api/bookings           - Create new booking
GET  /api/bookings/:id       - Get booking details
PUT  /api/bookings/:id       - Modify booking (admin)
DELETE /api/bookings/:id     - Cancel booking
```

### Database Schema
```sql
-- Services Table
CREATE TABLE services (
  id INTEGER PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  duration_minutes INTEGER NOT NULL,
  price DECIMAL(10,2),
  description TEXT,
  is_active BOOLEAN DEFAULT true
);

-- Bookings Table (Anti-Double Booking)
CREATE TABLE bookings (
  id INTEGER PRIMARY KEY,
  service_id INTEGER REFERENCES services(id),
  client_name VARCHAR(100) NOT NULL,
  client_phone VARCHAR(20) NOT NULL,
  client_email VARCHAR(255) NOT NULL,
  appointment_date DATE NOT NULL,
  start_time TIME NOT NULL,
  end_time TIME NOT NULL,
  notes TEXT,
  status ENUM('confirmed', 'cancelled', 'completed') DEFAULT 'confirmed',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  version INTEGER DEFAULT 1,
  UNIQUE(appointment_date, start_time)  -- Prevents double booking
);

-- Blocked Times (for breaks, holidays)
CREATE TABLE blocked_times (
  id INTEGER PRIMARY KEY,
  block_date DATE NOT NULL,
  start_time TIME,
  end_time TIME,
  all_day BOOLEAN DEFAULT false,
  reason VARCHAR(255)
);
```

---

## Anti-Double Booking Strategy

### Layer 1: Frontend
- Fetch fresh availability before showing slots
- Disable slot immediately on selection
- Re-verify availability on form submission

### Layer 2: API
- Validate slot availability in transaction
- Use database-level UNIQUE constraint
- Return conflict error with alternative slots

### Layer 3: Database
- UNIQUE constraint on (date, start_time)
- Optimistic locking with version field
- Transaction isolation level: SERIALIZABLE

### Conflict Resolution Flow
```
1. Client selects slot
2. API receives booking request
3. BEGIN TRANSACTION
4. SELECT slot WHERE date=X AND time=Y FOR UPDATE
5. IF slot exists → ROLLBACK, return alternatives
6. ELSE → INSERT booking, COMMIT
7. Send confirmation email
```

---

## Email Configuration

### For Domain-Branded Emails
**Option 1: SMTP Provider**
- Configure SendGrid, Mailgun, or Amazon SES
- Use your domain with SPF/DKIM records
- Templates stored in system

**Option 2: Transactional Email Service**
- Postmark, Resend, or similar
- Higher deliverability
- Built-in templates

### Email Types
| Email | Trigger | Timing |
|-------|---------|--------|
| Confirmation | Booking created | Immediate |
| Reminder | Before appointment | 24h & 2h before |
| Follow-up | After appointment | Next day |
| Cancellation | Booking cancelled | Immediate |

---

## Embedding Instructions

### React/Next.js
```jsx
import SalonBooking from './SalonBooking';

function MyWebsite() {
  return (
    <div>
      <SalonBooking 
        apiEndpoint="https://yourdomain.com/api"
        salonName="Your Salon Name"
      />
    </div>
  );
}
```

### Plain HTML (iframe)
```html
<iframe 
  src="https://yourdomain.com/booking-widget"
  width="100%"
  height="800"
  frameborder="0"
></iframe>
```

### Script Embed
```html
<div id="salon-booking-widget"></div>
<script src="https://yourdomain.com/booking-widget.js"></script>
<script>
  SalonBooking.init({
    container: '#salon-booking-widget',
    apiEndpoint: 'https://yourdomain.com/api'
  });
</script>
```

---

## Configuration Options

```javascript
const config = {
  // Business Settings
  salonName: "Your Salon Name",
  salonAddress: "123 Main St, City",
  salonPhone: "+1 234 567 8900",
  
  // Working Hours
  workingHours: {
    monday: { start: "09:00", end: "18:00" },
    tuesday: { start: "09:00", end: "18:00" },
    wednesday: { start: "09:00", end: "18:00" },
    thursday: { start: "09:00", end: "20:00" },
    friday: { start: "09:00", end: "20:00" },
    saturday: { start: "10:00", end: "16:00" },
    sunday: null  // Closed
  },
  
  // Booking Settings
  slotDuration: 15,           // minutes
  bufferBetweenBookings: 15,  // minutes
  advanceBookingDays: 30,     // how far ahead clients can book
  minimumNotice: 24,          // hours before appointment
  
  // Services
  services: [
    { id: 1, name: "Haircut", duration: 45, price: 50 },
    { id: 2, name: "Color", duration: 90, price: 120 },
    { id: 3, name: "Highlights", duration: 120, price: 150 },
    { id: 4, name: "Blowout", duration: 30, price: 35 },
    { id: 5, name: "Treatment", duration: 60, price: 80 }
  ]
};
```

---

## Security Considerations

1. **Input Sanitization**: All user inputs sanitized server-side
2. **Rate Limiting**: Max 10 booking attempts per IP per hour
3. **CAPTCHA**: Optional reCAPTCHA for bot protection
4. **HTTPS**: All API calls over encrypted connection
5. **Data Privacy**: GDPR-compliant data handling
6. **No Payment Data**: No credit card info stored in this system

---

## Future Enhancements (Out of Scope)

- [ ] Online payment integration
- [ ] SMS reminders
- [ ] Multiple stylist support
- [ ] Loyalty program
- [ ] Gift cards
- [ ] Waitlist functionality
- [ ] Client account login
- [ ] Analytics dashboard

---

## Deliverables

1. ✅ **Product Specification** (this document)
2. ✅ **Frontend Widget** (React component - embeddable artifact)
3. 📋 **Backend Setup Guide** (can be provided on request)
4. 📋 **Email Templates** (can be provided on request)

---

*Document Version: 1.0*  
*Created: January 2026*
