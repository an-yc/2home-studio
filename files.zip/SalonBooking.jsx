import React, { useState, useMemo } from 'react';

// ═══════════════════════════════════════════════════════════════════════════════
// HAIR SALON BOOKING SYSTEM - Embeddable React Component
// ═══════════════════════════════════════════════════════════════════════════════
// Configuration: Edit this section to customize for your salon
// ═══════════════════════════════════════════════════════════════════════════════

const CONFIG = {
  salonName: "Studio Luxe",
  salonTagline: "Where Style Meets Elegance",
  
  services: [
    { id: 1, name: "Signature Haircut", duration: 45, price: 65, description: "Precision cut with consultation" },
    { id: 2, name: "Color Transformation", duration: 90, price: 150, description: "Full color with gloss treatment" },
    { id: 3, name: "Balayage & Highlights", duration: 120, price: 200, description: "Hand-painted dimension" },
    { id: 4, name: "Luxury Blowout", duration: 30, price: 45, description: "Styled to perfection" },
    { id: 5, name: "Deep Conditioning", duration: 45, price: 75, description: "Intensive hair therapy" },
  ],
  
  workingHours: {
    0: null, // Sunday - closed
    1: { start: 10, end: 19 }, // Monday
    2: { start: 10, end: 19 }, // Tuesday
    3: { start: 10, end: 19 }, // Wednesday
    4: { start: 10, end: 20 }, // Thursday
    5: { start: 10, end: 20 }, // Friday
    6: { start: 9, end: 17 },  // Saturday
  },
  
  slotInterval: 30, // minutes between available slots
  advanceBookingDays: 30,
  bufferMinutes: 15,
};

// ═══════════════════════════════════════════════════════════════════════════════
// MOCK DATABASE - Replace with your actual backend API calls
// ═══════════════════════════════════════════════════════════════════════════════

const mockBookings = [
  { date: '2026-01-30', startTime: '10:00', endTime: '10:45' },
  { date: '2026-01-30', startTime: '14:00', endTime: '15:30' },
  { date: '2026-01-31', startTime: '11:00', endTime: '12:30' },
];

// ═══════════════════════════════════════════════════════════════════════════════
// MAIN COMPONENT
// ═══════════════════════════════════════════════════════════════════════════════

export default function SalonBooking() {
  const [step, setStep] = useState(1);
  const [selectedService, setSelectedService] = useState(null);
  const [selectedDate, setSelectedDate] = useState(null);
  const [selectedTime, setSelectedTime] = useState(null);
  const [formData, setFormData] = useState({ name: '', phone: '', email: '', notes: '' });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [bookingComplete, setBookingComplete] = useState(false);
  const [bookings, setBookings] = useState(mockBookings);

  // Generate available dates (next 30 days, excluding closed days)
  const availableDates = useMemo(() => {
    const dates = [];
    const today = new Date();
    for (let i = 1; i <= CONFIG.advanceBookingDays; i++) {
      const date = new Date(today);
      date.setDate(today.getDate() + i);
      const dayOfWeek = date.getDay();
      if (CONFIG.workingHours[dayOfWeek]) {
        dates.push(date);
      }
    }
    return dates;
  }, []);

  // Generate time slots for selected date
  const availableSlots = useMemo(() => {
    if (!selectedDate || !selectedService) return [];
    
    const dayOfWeek = selectedDate.getDay();
    const hours = CONFIG.workingHours[dayOfWeek];
    if (!hours) return [];
    
    const slots = [];
    const dateStr = selectedDate.toISOString().split('T')[0];
    const serviceDuration = selectedService.duration + CONFIG.bufferMinutes;
    
    for (let hour = hours.start; hour < hours.end; hour++) {
      for (let min = 0; min < 60; min += CONFIG.slotInterval) {
        const timeStr = `${hour.toString().padStart(2, '0')}:${min.toString().padStart(2, '0')}`;
        const slotStart = hour * 60 + min;
        const slotEnd = slotStart + serviceDuration;
        
        // Check if slot would extend past working hours
        if (slotEnd > hours.end * 60) continue;
        
        // Check for conflicts with existing bookings
        const hasConflict = bookings.some(booking => {
          if (booking.date !== dateStr) return false;
          const [bStartH, bStartM] = booking.startTime.split(':').map(Number);
          const [bEndH, bEndM] = booking.endTime.split(':').map(Number);
          const bookingStart = bStartH * 60 + bStartM;
          const bookingEnd = bEndH * 60 + bEndM;
          return !(slotEnd <= bookingStart || slotStart >= bookingEnd);
        });
        
        if (!hasConflict) {
          slots.push(timeStr);
        }
      }
    }
    return slots;
  }, [selectedDate, selectedService, bookings]);

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim() || formData.name.trim().length < 2) {
      newErrors.name = 'Please enter your full name';
    }
    if (!formData.phone.trim() || !/^[\d\s\-+()]{8,}$/.test(formData.phone)) {
      newErrors.phone = 'Please enter a valid phone number';
    }
    if (!formData.email.trim() || !/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)) {
      newErrors.email = 'Please enter a valid email address';
    }
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async () => {
    if (!validateForm()) return;
    
    setIsSubmitting(true);
    
    // Simulate API call - Replace with actual backend integration
    await new Promise(resolve => setTimeout(resolve, 1500));
    
    // Add to local bookings (in real app, this comes from backend)
    const dateStr = selectedDate.toISOString().split('T')[0];
    const [startH, startM] = selectedTime.split(':').map(Number);
    const endMinutes = startH * 60 + startM + selectedService.duration;
    const endTime = `${Math.floor(endMinutes / 60).toString().padStart(2, '0')}:${(endMinutes % 60).toString().padStart(2, '0')}`;
    
    setBookings(prev => [...prev, {
      date: dateStr,
      startTime: selectedTime,
      endTime: endTime
    }]);
    
    setIsSubmitting(false);
    setBookingComplete(true);
  };

  const resetBooking = () => {
    setStep(1);
    setSelectedService(null);
    setSelectedDate(null);
    setSelectedTime(null);
    setFormData({ name: '', phone: '', email: '', notes: '' });
    setErrors({});
    setBookingComplete(false);
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'short', 
      month: 'short', 
      day: 'numeric' 
    });
  };

  const formatTime = (time) => {
    const [hours, minutes] = time.split(':');
    const h = parseInt(hours);
    const ampm = h >= 12 ? 'PM' : 'AM';
    const h12 = h % 12 || 12;
    return `${h12}:${minutes} ${ampm}`;
  };

  // ═══════════════════════════════════════════════════════════════════════════
  // RENDER
  // ═══════════════════════════════════════════════════════════════════════════

  if (bookingComplete) {
    return (
      <div className="min-h-screen bg-stone-50 flex items-center justify-center p-4" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>
        <div className="bg-white rounded-2xl shadow-2xl p-12 max-w-lg w-full text-center border border-stone-200">
          <div className="w-20 h-20 bg-emerald-100 rounded-full flex items-center justify-center mx-auto mb-6">
            <svg className="w-10 h-10 text-emerald-600" fill="none" stroke="currentColor" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M5 13l4 4L19 7" />
            </svg>
          </div>
          <h2 className="text-3xl font-light text-stone-800 mb-3" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>Booking Confirmed</h2>
          <p className="text-stone-500 mb-8">A confirmation email has been sent to {formData.email}</p>
          
          <div className="bg-stone-50 rounded-xl p-6 mb-8 text-left">
            <div className="space-y-3">
              <div className="flex justify-between">
                <span className="text-stone-500">Service</span>
                <span className="font-medium text-stone-800">{selectedService.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Date</span>
                <span className="font-medium text-stone-800">{formatDate(selectedDate)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Time</span>
                <span className="font-medium text-stone-800">{formatTime(selectedTime)}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-stone-500">Duration</span>
                <span className="font-medium text-stone-800">{selectedService.duration} minutes</span>
              </div>
            </div>
          </div>
          
          <button
            onClick={resetBooking}
            className="w-full py-4 bg-stone-800 text-white rounded-xl hover:bg-stone-700 transition-all font-medium tracking-wide"
          >
            Book Another Appointment
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-stone-50" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>
      {/* Header */}
      <div className="bg-stone-900 text-white py-12 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl md:text-5xl font-light tracking-wide mb-2" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>
            {CONFIG.salonName}
          </h1>
          <p className="text-stone-400 text-lg tracking-widest uppercase text-sm">{CONFIG.salonTagline}</p>
        </div>
      </div>

      {/* Progress Steps */}
      <div className="bg-white border-b border-stone-200 sticky top-0 z-10">
        <div className="max-w-4xl mx-auto px-6 py-4">
          <div className="flex items-center justify-center gap-2 md:gap-4">
            {[
              { num: 1, label: 'Service' },
              { num: 2, label: 'Date & Time' },
              { num: 3, label: 'Your Details' },
              { num: 4, label: 'Confirm' }
            ].map((s, i) => (
              <React.Fragment key={s.num}>
                <div 
                  className={`flex items-center gap-2 cursor-pointer transition-all ${
                    step >= s.num ? 'text-stone-800' : 'text-stone-300'
                  }`}
                  onClick={() => step > s.num && setStep(s.num)}
                >
                  <div className={`w-8 h-8 rounded-full flex items-center justify-center text-sm font-medium transition-all ${
                    step === s.num ? 'bg-stone-800 text-white' : 
                    step > s.num ? 'bg-emerald-100 text-emerald-700' : 'bg-stone-100 text-stone-400'
                  }`}>
                    {step > s.num ? '✓' : s.num}
                  </div>
                  <span className="hidden md:inline text-sm font-medium">{s.label}</span>
                </div>
                {i < 3 && <div className={`w-8 md:w-16 h-px ${step > s.num ? 'bg-emerald-300' : 'bg-stone-200'}`} />}
              </React.Fragment>
            ))}
          </div>
        </div>
      </div>

      {/* Main Content */}
      <div className="max-w-4xl mx-auto px-6 py-10">
        
        {/* Step 1: Service Selection */}
        {step === 1 && (
          <div className="animate-fadeIn">
            <h2 className="text-2xl font-light text-stone-800 mb-2 text-center" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>
              Select Your Service
            </h2>
            <p className="text-stone-500 text-center mb-8">Choose the service that suits you best</p>
            
            <div className="grid gap-4 md:grid-cols-2">
              {CONFIG.services.map(service => (
                <button
                  key={service.id}
                  onClick={() => { setSelectedService(service); setStep(2); }}
                  className={`p-6 rounded-xl text-left transition-all border-2 hover:shadow-lg ${
                    selectedService?.id === service.id 
                      ? 'border-stone-800 bg-stone-50 shadow-lg' 
                      : 'border-stone-200 bg-white hover:border-stone-400'
                  }`}
                >
                  <div className="flex justify-between items-start mb-2">
                    <h3 className="text-lg font-medium text-stone-800">{service.name}</h3>
                    <span className="text-stone-600 font-medium">${service.price}</span>
                  </div>
                  <p className="text-stone-500 text-sm mb-3">{service.description}</p>
                  <div className="flex items-center gap-2 text-stone-400 text-sm">
                    <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                      <path strokeLinecap="round" strokeLinejoin="round" strokeWidth="2" d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                    </svg>
                    {service.duration} minutes
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}

        {/* Step 2: Date & Time Selection */}
        {step === 2 && (
          <div className="animate-fadeIn">
            <h2 className="text-2xl font-light text-stone-800 mb-2 text-center" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>
              Choose Date & Time
            </h2>
            <p className="text-stone-500 text-center mb-8">
              {selectedService.name} • {selectedService.duration} minutes
            </p>

            {/* Date Selection */}
            <div className="mb-8">
              <h3 className="text-sm font-medium text-stone-600 uppercase tracking-wide mb-4">Select Date</h3>
              <div className="flex gap-2 overflow-x-auto pb-4 -mx-2 px-2">
                {availableDates.slice(0, 14).map(date => {
                  const isSelected = selectedDate?.toDateString() === date.toDateString();
                  return (
                    <button
                      key={date.toISOString()}
                      onClick={() => { setSelectedDate(date); setSelectedTime(null); }}
                      className={`flex-shrink-0 w-20 py-4 rounded-xl text-center transition-all border-2 ${
                        isSelected 
                          ? 'border-stone-800 bg-stone-800 text-white' 
                          : 'border-stone-200 bg-white hover:border-stone-400'
                      }`}
                    >
                      <div className={`text-xs uppercase tracking-wide ${isSelected ? 'text-stone-300' : 'text-stone-400'}`}>
                        {date.toLocaleDateString('en-US', { weekday: 'short' })}
                      </div>
                      <div className="text-2xl font-light my-1">{date.getDate()}</div>
                      <div className={`text-xs ${isSelected ? 'text-stone-300' : 'text-stone-500'}`}>
                        {date.toLocaleDateString('en-US', { month: 'short' })}
                      </div>
                    </button>
                  );
                })}
              </div>
            </div>

            {/* Time Selection */}
            {selectedDate && (
              <div className="animate-fadeIn">
                <h3 className="text-sm font-medium text-stone-600 uppercase tracking-wide mb-4">
                  Available Times for {formatDate(selectedDate)}
                </h3>
                {availableSlots.length > 0 ? (
                  <div className="grid grid-cols-3 md:grid-cols-5 gap-3">
                    {availableSlots.map(time => {
                      const isSelected = selectedTime === time;
                      return (
                        <button
                          key={time}
                          onClick={() => setSelectedTime(time)}
                          className={`py-3 px-4 rounded-lg text-center transition-all border-2 ${
                            isSelected 
                              ? 'border-stone-800 bg-stone-800 text-white' 
                              : 'border-stone-200 bg-white hover:border-stone-400'
                          }`}
                        >
                          {formatTime(time)}
                        </button>
                      );
                    })}
                  </div>
                ) : (
                  <div className="text-center py-12 bg-stone-100 rounded-xl">
                    <p className="text-stone-500">No available slots for this date.</p>
                    <p className="text-stone-400 text-sm mt-1">Please select another date.</p>
                  </div>
                )}
              </div>
            )}

            {/* Navigation */}
            <div className="flex gap-4 mt-10">
              <button
                onClick={() => setStep(1)}
                className="flex-1 py-4 border-2 border-stone-300 text-stone-600 rounded-xl hover:bg-stone-50 transition-all font-medium"
              >
                Back
              </button>
              <button
                onClick={() => setStep(3)}
                disabled={!selectedDate || !selectedTime}
                className={`flex-1 py-4 rounded-xl font-medium transition-all ${
                  selectedDate && selectedTime
                    ? 'bg-stone-800 text-white hover:bg-stone-700'
                    : 'bg-stone-200 text-stone-400 cursor-not-allowed'
                }`}
              >
                Continue
              </button>
            </div>
          </div>
        )}

        {/* Step 3: Client Details */}
        {step === 3 && (
          <div className="animate-fadeIn">
            <h2 className="text-2xl font-light text-stone-800 mb-2 text-center" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>
              Your Details
            </h2>
            <p className="text-stone-500 text-center mb-8">We'll send your confirmation here</p>

            <div className="max-w-md mx-auto">
              <div className="space-y-5">
                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Full Name *</label>
                  <input
                    type="text"
                    value={formData.name}
                    onChange={(e) => setFormData(prev => ({ ...prev, name: e.target.value }))}
                    className={`w-full px-4 py-3 rounded-lg border-2 transition-all outline-none ${
                      errors.name ? 'border-red-300 bg-red-50' : 'border-stone-200 focus:border-stone-400'
                    }`}
                    placeholder="Enter your full name"
                  />
                  {errors.name && <p className="text-red-500 text-sm mt-1">{errors.name}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Phone Number *</label>
                  <input
                    type="tel"
                    value={formData.phone}
                    onChange={(e) => setFormData(prev => ({ ...prev, phone: e.target.value }))}
                    className={`w-full px-4 py-3 rounded-lg border-2 transition-all outline-none ${
                      errors.phone ? 'border-red-300 bg-red-50' : 'border-stone-200 focus:border-stone-400'
                    }`}
                    placeholder="+1 (234) 567-8900"
                  />
                  {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Email Address *</label>
                  <input
                    type="email"
                    value={formData.email}
                    onChange={(e) => setFormData(prev => ({ ...prev, email: e.target.value }))}
                    className={`w-full px-4 py-3 rounded-lg border-2 transition-all outline-none ${
                      errors.email ? 'border-red-300 bg-red-50' : 'border-stone-200 focus:border-stone-400'
                    }`}
                    placeholder="your@email.com"
                  />
                  {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
                </div>

                <div>
                  <label className="block text-sm font-medium text-stone-700 mb-2">Special Notes (Optional)</label>
                  <textarea
                    value={formData.notes}
                    onChange={(e) => setFormData(prev => ({ ...prev, notes: e.target.value }))}
                    rows={3}
                    className="w-full px-4 py-3 rounded-lg border-2 border-stone-200 focus:border-stone-400 transition-all outline-none resize-none"
                    placeholder="Any special requests or notes..."
                  />
                </div>
              </div>

              <div className="flex gap-4 mt-10">
                <button
                  onClick={() => setStep(2)}
                  className="flex-1 py-4 border-2 border-stone-300 text-stone-600 rounded-xl hover:bg-stone-50 transition-all font-medium"
                >
                  Back
                </button>
                <button
                  onClick={() => { if (validateForm()) setStep(4); }}
                  className="flex-1 py-4 bg-stone-800 text-white rounded-xl hover:bg-stone-700 transition-all font-medium"
                >
                  Review Booking
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Step 4: Confirmation */}
        {step === 4 && (
          <div className="animate-fadeIn">
            <h2 className="text-2xl font-light text-stone-800 mb-2 text-center" style={{ fontFamily: "'Cormorant Garamond', Georgia, serif" }}>
              Confirm Your Booking
            </h2>
            <p className="text-stone-500 text-center mb-8">Please review your appointment details</p>

            <div className="max-w-md mx-auto">
              <div className="bg-white rounded-2xl border-2 border-stone-200 overflow-hidden">
                {/* Service Summary */}
                <div className="p-6 border-b border-stone-100">
                  <h3 className="text-xs font-medium text-stone-400 uppercase tracking-wide mb-3">Service</h3>
                  <div className="flex justify-between items-center">
                    <div>
                      <p className="text-lg font-medium text-stone-800">{selectedService.name}</p>
                      <p className="text-stone-500 text-sm">{selectedService.duration} minutes</p>
                    </div>
                    <span className="text-xl font-light text-stone-700">${selectedService.price}</span>
                  </div>
                </div>

                {/* Date & Time */}
                <div className="p-6 border-b border-stone-100">
                  <h3 className="text-xs font-medium text-stone-400 uppercase tracking-wide mb-3">Appointment</h3>
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-stone-100 rounded-xl flex flex-col items-center justify-center">
                      <span className="text-lg font-medium text-stone-800">{selectedDate.getDate()}</span>
                      <span className="text-xs text-stone-500">{selectedDate.toLocaleDateString('en-US', { month: 'short' })}</span>
                    </div>
                    <div>
                      <p className="text-lg font-medium text-stone-800">{formatTime(selectedTime)}</p>
                      <p className="text-stone-500 text-sm">{selectedDate.toLocaleDateString('en-US', { weekday: 'long' })}</p>
                    </div>
                  </div>
                </div>

                {/* Contact Info */}
                <div className="p-6">
                  <h3 className="text-xs font-medium text-stone-400 uppercase tracking-wide mb-3">Contact Details</h3>
                  <div className="space-y-2 text-sm">
                    <p className="text-stone-800">{formData.name}</p>
                    <p className="text-stone-500">{formData.phone}</p>
                    <p className="text-stone-500">{formData.email}</p>
                    {formData.notes && (
                      <p className="text-stone-400 italic mt-2">"{formData.notes}"</p>
                    )}
                  </div>
                </div>
              </div>

              <div className="flex gap-4 mt-8">
                <button
                  onClick={() => setStep(3)}
                  disabled={isSubmitting}
                  className="flex-1 py-4 border-2 border-stone-300 text-stone-600 rounded-xl hover:bg-stone-50 transition-all font-medium disabled:opacity-50"
                >
                  Back
                </button>
                <button
                  onClick={handleSubmit}
                  disabled={isSubmitting}
                  className="flex-1 py-4 bg-stone-800 text-white rounded-xl hover:bg-stone-700 transition-all font-medium disabled:opacity-50 flex items-center justify-center gap-2"
                >
                  {isSubmitting ? (
                    <>
                      <svg className="animate-spin w-5 h-5" fill="none" viewBox="0 0 24 24">
                        <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                        <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z" />
                      </svg>
                      Booking...
                    </>
                  ) : (
                    'Confirm Booking'
                  )}
                </button>
              </div>

              <p className="text-center text-stone-400 text-xs mt-6">
                A confirmation email will be sent to your email address
              </p>
            </div>
          </div>
        )}
      </div>

      {/* Inline Styles for Animation */}
      <style>{`
        @keyframes fadeIn {
          from { opacity: 0; transform: translateY(10px); }
          to { opacity: 1; transform: translateY(0); }
        }
        .animate-fadeIn {
          animation: fadeIn 0.3s ease-out;
        }
      `}</style>
    </div>
  );
}
